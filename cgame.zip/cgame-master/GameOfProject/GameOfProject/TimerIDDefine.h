#define  SNAKETIMER     0x01

#define  BIRDMOVETIMER  0x03
#define  GUNMOVETIMER   0x04
#define  BIRDFLYLEVELTIMER 0x05
//���˾ͼ��100s
#define  MANMOVETIMER     0x06
#define  MANLEVELTIMER    0x07
//ship
#define  SHIPMOVETIMER   0x08
#define  SHIPCANTAKEGUN  0x09


#define  FISHMOVETIMER   0x0a
#define  FISHADDHARD     0x0b
#define  FISHHARDADD     0x0c
#define  FISHHARDADD2    0x0d