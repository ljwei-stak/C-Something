#pragma once
#include "GameFather.h"
class CColorBoxControler
	:public CGameFather
{
public:
	CColorBoxControler(void);
	~CColorBoxControler(void);
// 	virtual int OnGameTimer(UINT_PTR nIDEvent);
// 	virtual BOOL PreTranslateMessage(MSG* pMsg);
private:

};
