#include "StdAfx.h"
#include "ColorBoxControler.h"

CColorBoxControler::CColorBoxControler(void)
{
}

CColorBoxControler::~CColorBoxControler(void)
{
}
